#ifndef LAYER_METADATA_H
#define LAYER_METADATA_H

#include <string>

namespace yannpp {
    struct layer_metadata_t {
        std::string name;
    };
}

#endif // LAYER_METADATA_H
